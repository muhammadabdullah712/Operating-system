#include<iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

void main_game();

int main()
{
	int n = 0;
	char ch;
	cout<<"\t**************************************************************"<<endl;
	cout<<"\t\t\tWELCOME TO WORD SEARCH GAME"<<endl;
	cout<<"\t**************************************************************"<<endl;
	cout<<endl;
	cout<<"\t Rules : "<<endl;
	cout<<"\t ******"<<endl;
	cout<<"\t\tYou have to select only one character at a time from the following hidden characters.You have 3 limited attempts.Play safely.Good luck."<<endl;
	cout<<"\t Do You want to start game :  (y/n) ";
	cin>>ch;
	if(ch=='y')
	{
		main_game();
	}
	
	return 0;
}
void main_game()
{
	char ch;
	char choice = 'y';
	int win=0,lose=0;

	while (choice != 'n')
	{
		int attempts = 0;
		bool guessed_word = false;

		srand(time(NULL));
		int select_word = rand() % 5 + 1;

		char easy_list[100] = { "mouse elephant rabbit tries chair " };
		char easy_listS[100] = { "m*u*e e*eph*nt ra**i* t*i*s c*ai* " };
		char hard_listS[100] = { "m*u** e*e*h**t ra**i* t*i** c**i* " };

		int level = 0;
		
		cout << "Select your level : " << endl;
		cout << "Enter 1 for easy : " << endl;
		cout << "Enter 2 for hard :" << endl;
		cin >> level;
		
		int word_count = 1;

		char word[10] = "\0";
		char wordS[10] = "\0";

		bool done = false;

		if (level == 1)
		 {

			for (int i = 0; easy_list[i] != '\0'; i++) 
			{

				while (easy_listS[i] == ' ' || select_word == 1) 
				{

					if (select_word != 1)
						word_count++;

					if (word_count == select_word || select_word == 1)
					 {

						if (select_word != 1)
							i++;

						for (int j = 0; ((easy_listS[i] != ' ') && (easy_listS[i] != '\0')); j++) 
						{

							word[j] = easy_list[i];
							wordS[j] = easy_listS[i];
							i++;
							done = true;
						}
						break;
					}
					break;
				}
				if (done)
					break;
			}
		}
		else if (level == 2) 
		{

			for (int i = 0; easy_list[i] != '\0'; i++)
			 {

				while (hard_listS[i] == ' ' || select_word == 1) 
				{

					if (select_word != 1)
						word_count++;

					if (word_count == select_word || select_word == 1) 
					{

						if (select_word != 1)
							i++;

						for (int j = 0; ((hard_listS[i] != ' ') && (hard_listS[i] != '\0')); j++) 
						{

							word[j] = easy_list[i];
							wordS[j] = hard_listS[i];
							i++;
							done = true;
						}
						break;
					}
					break;
				}
				if (done)
					break;
			}
		}
		

		cout << wordS << endl;

		while (attempts != 3)
		{

			bool guessed_ch = false;

			cout << "Enter Character : ";
			cin >> ch;

			for (int j = 0; word[j] != '\0'; j++) 
			{

				if (wordS[j] == '*')
				{

					if (word[j] == ch)
					{
						wordS[j] = ch;
						cout << wordS << endl;

						guessed_word = true;
						guessed_ch = true;
					}
				}
			}

			if (!guessed_ch) 
			{

				guessed_word = false;
				if (attempts == 3)
				{
					break;
				}
				attempts++;
			}
			bool com = true;
			for (int j = 0; wordS[j] != '\0'; j++) 
			{

				if (wordS[j] == '*')
				 {

					com = false;
					break;
				}
			}

			if (com || attempts == 3) 
			{

				break;
			}

		}
		if (guessed_word == true)
		{
			win++;
			cout << "YOU WIN" << endl;
			cout << "Do you wanna play again ? Y/N" << endl;
			cin >> choice;
		}
		else
		{
			lose++;
			cout << "YOU LOSE" << endl;
			cout << "Do you wanna play again ? Y/N" << endl;
			cin >> choice;
		}
	}
	cout<<"NUMBER OF WINS : "<<win<<endl;
	cout<<"NUMBER OF LOSES : "<<lose<<endl;
}

